procedural-planet
=================

Proceural planet in WebGL and three.js

See the [resulting 3D animation](http://holgerl.github.io/procedural-planet/)

See the [blog post](http://open.bekk.no/procedural-planet-in-webgl-and-three-js)

See also [part 2](https://github.com/holgerl/procedural-planet-part-2)
